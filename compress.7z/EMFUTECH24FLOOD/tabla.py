import boto3
#Este código crea una tabla en Amazon Timestream para almacenar datos de los rios de forma personalizada
# Crear un cliente para Timestream
timestream_client = boto3.client('timestream-write')

# Parámetros de la tabla
database_name = "SensorsDB"
table_name = "RiverData"
retention_properties = {
    "MemoryStoreRetentionPeriodInHours": 24,
    "MagneticStoreRetentionPeriodInDays": 7
}

# Crear la tabla
try:
    response = timestream_client.create_table(
        DatabaseName=database_name,
        TableName=table_name,
        RetentionProperties=retention_properties
    )
    print(f"Tabla '{table_name}' creada con éxito en la base de datos '{database_name}'.")
    print(response)
except Exception as e:
    print("Error al crear la tabla:", e)
