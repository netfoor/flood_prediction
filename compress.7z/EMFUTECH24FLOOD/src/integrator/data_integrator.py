# src/integrator/data_integrator.py
from datetime import datetime, timedelta
import boto3
from typing import Dict, Optional
from dataclasses import dataclass
import logging
import time

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class IntegratedData:
    """Estructura para datos combinados"""
    timestamp: int
    location: str
    temperature: float
    precipitation: float
    humidity: float
    ndvi: float
    soil_moisture: float
    evapotranspiration: float
    elevation: float
    slope: float
    # Agregamos campos para tracking
    weather_timestamp: str
    satellite_timestamp: str

class DataIntegrator:
    def __init__(self, region_name: str = 'ap-northeast-1'):
        """
        Inicializa el integrador de datos
        Args:
            region_name: Región de AWS
        """
        try:
            self.timestream_query = boto3.client('timestream-query', region_name=region_name)
            self.timestream_write = boto3.client('timestream-write', region_name=region_name)
            logger.info(f"Inicializado cliente Timestream en región {region_name}")
        except Exception as e:
            logger.error(f"Error inicializando clientes Timestream: {str(e)}")
            raise

    def save_to_timestream_with_retries(self, record, max_retries=3):
        """
        Guarda un registro en Timestream con reintentos en caso de fallos.
        """
        retries = 0
        while retries < max_retries:
            try:
                self.timestream_write.write_records(
                    DatabaseName='SensorsDB',  # Reemplaza con tu nombre de base de datos
                    TableName='IntegratedData',  # Reemplaza con tu nombre de tabla
                    Records=[record]
                )
                logger.info("Datos guardados exitosamente en Timestream")
                return
            except Exception as e:
                retries += 1
                logger.error(f"Error guardando datos en Timestream (Intento {retries}): {str(e)}")
                if retries < max_retries:
                    time.sleep(2 ** retries)  # Backoff exponencial
        raise Exception(f"Fallo al guardar datos en Timestream después de {max_retries} intentos")


    def get_data_from_timestream(self, query: str, description: str) -> Optional[Dict]:
        """
        Realiza una consulta genérica a Timestream con mejor manejo de errores.
        """
        try:
            logger.info(f"Ejecutando consulta para {description}")
            result = self.timestream_query.query(QueryString=query)
            
            if not result.get('Rows'):
                logger.warning(f"No se encontraron resultados para {description}")
                return None
                
            data = self._parse_timestream_row(result['Rows'][0], result['ColumnInfo'])
            logger.info(f"Datos obtenidos exitosamente para {description}")
            return data
            
        except Exception as e:
            logger.error(f"Error en consulta para {description}: {str(e)}")
            raise

    def get_latest_data_with_fallback(self, query_template: str, description: str, 
                                location: str, max_days: int = 7) -> Optional[Dict]:
        """
        Intenta obtener datos con fallback mejorado
        """
        for days in range(0, max_days):
            try:
                start_time = f"{days + 1}d"  # Cambiado el formato de ago()
                query = query_template.format(
                    location=location,
                    start_time=start_time
                )
                
                if days > 0:
                    logger.warning(f"Intentando obtener datos de hace {days + 1} días para {description}")
                    
                data = self.get_data_from_timestream(query, description)
                if data:
                    if days > 0:
                        logger.info(f"Encontrados datos de {description} de hace {days + 1} días")
                    return data
                    
            except Exception as e:
                logger.error(f"Error en intento {days + 1} para {description}: {str(e)}")
                
        logger.warning(f"No se encontraron datos después de buscar {max_days} días para {description}")
        return None

    def get_latest_weather_data(self, location: str) -> Optional[Dict]:
        """Obtiene los últimos datos meteorológicos con columnas específicas"""
        query_template = """
        SELECT time, Temperature_Current_Celsius, Humidity_Percent, Precipitation_1h_mm
        FROM "SensorsDB"."WeatherData"
        WHERE Location = '{location}'
        AND time > ago({start_time})
        ORDER BY time DESC
        LIMIT 1
        """
        return self.get_latest_data_with_fallback(query_template, "datos del clima", location)


    def get_latest_satellite_data(self, location: str) -> Optional[Dict]:
        """Obtiene los últimos datos satelitales con columnas específicas"""
        query_template = """
        SELECT time, NDVI, SoilMoisture, Evapotranspiration, Elevation, Slope
        FROM "SensorsDB"."SatelliteData"
        WHERE Location = '{location}'
        AND time > ago({start_time})
        ORDER BY time DESC
        LIMIT 1
        """
        return self.get_latest_data_with_fallback(query_template, "datos satelitales", location)


    def _parse_timestream_row(self, row: Dict, column_info: Dict) -> Dict:
        """
        Parsea una fila de Timestream a un diccionario
        """
        parsed_data = {}
        try:
            for i, data in enumerate(row['Data']):
                column_name = column_info[i]['Name']
                raw_value = data.get('ScalarValue')
                logger.info(f"Procesando columna: {column_name}, valor crudo: {raw_value}")

                if raw_value is not None:
                    try:
                        if column_info[i]['Type'] in ['DOUBLE', 'BIGINT']:
                            parsed_data[column_name] = float(raw_value)
                        else:
                            parsed_data[column_name] = raw_value
                    except ValueError:
                        logger.warning(f"No se pudo convertir el valor '{raw_value}' de la columna '{column_name}' a float")
                        parsed_data[column_name] = raw_value

            logger.info(f"Datos parseados: {parsed_data}")
            return parsed_data

        except Exception as e:
            logger.error(f"Error parseando fila de Timestream: {str(e)}")
            raise


    def integrate_data(self, location: str) -> Optional[IntegratedData]:
        """
        Integra datos de ambas fuentes con mejor manejo de timestamp
        """
        try:
            logger.info(f"Iniciando integración de datos para {location}")
            weather_data = self.get_latest_weather_data(location)
            satellite_data = self.get_latest_satellite_data(location)

            # Loggea los datos obtenidos
            logger.info(f"Datos meteorológicos: {weather_data}")
            logger.info(f"Datos satelitales: {satellite_data}")

            if not weather_data:
                logger.error("No se encontraron datos meteorológicos recientes")
                return None
            if not satellite_data:
                logger.error("No se encontraron datos satelitales recientes")
                return None

            # Crea el objeto de datos integrados
            integrated = IntegratedData(
                timestamp=int(datetime.now().timestamp() * 1000),
                location=location,
                temperature=float(weather_data['Temperature_Current_Celsius']),
                precipitation=float(weather_data['Precipitation_1h_mm']),
                humidity=float(weather_data['Humidity_Percent']),
                ndvi=float(satellite_data['NDVI']),
                soil_moisture=float(satellite_data['SoilMoisture']),
                evapotranspiration=float(satellite_data['Evapotranspiration']),
                elevation=float(satellite_data['Elevation']),
                slope=float(satellite_data['Slope']),
                weather_timestamp=weather_data['time'],  # Asegúrate de que existe y es correcto
                satellite_timestamp=satellite_data['time']  # Asegúrate de que existe y es correcto
            )

            # Loggea el objeto integrado
            logger.info(f"Datos integrados: {integrated}")
            
            return integrated

        except Exception as e:
            logger.error(f"Error integrando datos: {str(e)}")
            raise



    def save_integrated_data(self, data: IntegratedData) -> None:
        """
        Guarda datos integrados con manejo de errores mejorado
        """
        try:
            record = {
                'Dimensions': [
                    {'Name': 'Location', 'Value': data.location}
                ],
                'MeasureName': 'IntegratedData',
                'MeasureValueType': 'MULTI',
                'Time': str(data.timestamp),
                'MeasureValues': [
                    {'Name': 'Temperature', 'Value': str(data.temperature), 'Type': 'DOUBLE'},
                    {'Name': 'Precipitation', 'Value': str(data.precipitation), 'Type': 'DOUBLE'},
                    {'Name': 'Humidity', 'Value': str(data.humidity), 'Type': 'DOUBLE'},
                    {'Name': 'NDVI', 'Value': str(data.ndvi), 'Type': 'DOUBLE'},
                    {'Name': 'SoilMoisture', 'Value': str(data.soil_moisture), 'Type': 'DOUBLE'},
                    {'Name': 'Evapotranspiration', 'Value': str(data.evapotranspiration), 'Type': 'DOUBLE'},
                    {'Name': 'Elevation', 'Value': str(data.elevation), 'Type': 'DOUBLE'},
                    {'Name': 'Slope', 'Value': str(data.slope), 'Type': 'DOUBLE'},
                    {'Name': 'WeatherTimestamp', 'Value': data.weather_timestamp, 'Type': 'VARCHAR'},
                    {'Name': 'SatelliteTimestamp', 'Value': data.satellite_timestamp, 'Type': 'VARCHAR'}
                ]
            }

            self.save_to_timestream_with_retries(record)

            
        except Exception as e:
            logger.error(f"Error guardando datos en Timestream: {str(e)}")
            raise