# src/predictor/flood_predictor.py
import xgboost as xgb
import boto3
import numpy as np
from typing import Dict, Optional
import joblib
from datetime import datetime
import logging
import os
from dataclasses import dataclass

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class PredictionResult:
    """Estructura para resultados de predicción"""
    location: str
    timestamp: int
    flood_probability: float
    risk_level: str
    features_used: Dict[str, float]

class FloodPredictor:
    def __init__(self, model_path: str, scaler_path: str, region_name: str = 'ap-northeast-1'):
        """
        Inicializa el predictor
        Args:
            model_path: Ruta al modelo guardado
            scaler_path: Ruta al scaler guardado
            region_name: Región de AWS
        """
        try:
            logger.info("Inicializando FloodPredictor")
            self.model = self._load_model(model_path)
            self.scaler = self._load_scaler(scaler_path)
            self.timestream_query = boto3.client('timestream-query', region_name=region_name)
            self.timestream_write = boto3.client('timestream-write', region_name=region_name)
            logger.info("Conexiones inicializadas exitosamente")
            
            # Features requeridas para el modelo
            self.required_features = [
                'Mean_NDVI',
                'Mean_Temperature_C',
                'Mean_Precipitation',
                'Elevation',
                'Slope',
                'Mean_Soil_Moisture',
                'Mean_Evapotranspiration'
            ]

            
        except Exception as e:
            logger.error(f"Error en inicialización: {str(e)}")
            raise

    def _load_model(self, model_path: str):
        """Carga el modelo entrenado"""
        try:
            logger.info(f"Cargando modelo desde {model_path}")
            return joblib.load(model_path)
        except Exception as e:
            logger.error(f"Error cargando modelo: {str(e)}")
            raise

    def _load_scaler(self, scaler_path: str):
        """Carga el scaler"""
        try:
            logger.info(f"Cargando scaler desde {scaler_path}")
            return joblib.load(scaler_path)
        except Exception as e:
            logger.error(f"Error cargando scaler: {str(e)}")
            raise

    def get_integrated_data(self, location: str) -> Optional[Dict]:
        """Obtiene datos integrados más recientes"""
        query = """
        SELECT NDVI,
            Temperature,
            Precipitation,
            Elevation,
            Slope,
            SoilMoisture,
            Evapotranspiration
        FROM "SensorsDB"."IntegratedData"
        WHERE Location = 'Tabasco'
        AND time > ago(6h)
        ORDER BY time DESC
        LIMIT 1
        """.format(location)
        
        try:
            logger.info(f"Obteniendo datos integrados para {location}")
            result = self.timestream_query.query(QueryString=query)
            if not result['Rows']:
                logger.warning("No se encontraron datos integrados recientes")
                return None

            data = self._parse_timestream_row(result['Rows'][0], result['ColumnInfo'])
            logger.info(f"Datos obtenidos y parseados: {data}")
            
            # Verificar columnas faltantes
            missing_columns = set(self.required_features) - set(data.keys())
            if missing_columns:
                logger.error(f"Faltan columnas requeridas: {missing_columns}")
                return None

            return data

        except Exception as e:
            logger.error(f"Error obteniendo datos integrados: {str(e)}")
            raise



    def _parse_timestream_row(self, row: Dict, column_info: Dict) -> Dict:
        """Parsea una fila de Timestream a un diccionario con nombres de variables esperados por el modelo"""
        parsed_data = {}
        try:
            # Mapeo de nombres de Timestream a los que el modelo espera
            column_mapping = {
                'NDVI': 'Mean_NDVI',
                'Temperature': 'Mean_Temperature_C',
                'Precipitation': 'Mean_Precipitation',
                'SoilMoisture': 'Mean_Soil_Moisture',
                'Evapotranspiration': 'Mean_Evapotranspiration',
                'Elevation': 'Elevation',
                'Slope': 'Slope'
            }
            
            for i, data in enumerate(row['Data']):
                column_name = column_info[i]['Name']
                if column_name in column_mapping and data.get('ScalarValue') is not None:
                    try:
                        value = data['ScalarValue']
                        # Usar el nombre que el modelo espera
                        mapped_name = column_mapping[column_name]
                        parsed_data[mapped_name] = float(value) if column_info[i]['Type']['ScalarType'] in ['DOUBLE', 'BIGINT'] else value
                    except ValueError:
                        logger.warning(f"Valor no numérico encontrado en {column_name}: {data['ScalarValue']}")
                        parsed_data[mapped_name] = None
                elif column_name in column_mapping:
                    parsed_data[column_mapping[column_name]] = None  # Si el valor es None
            logger.debug(f"Datos parseados: {parsed_data}")
            return parsed_data
        except Exception as e:
            logger.error(f"Error parseando datos: {str(e)}")
            raise



    def _get_risk_level(self, probability: float) -> str:
        """Determina nivel de riesgo basado en probabilidad"""
        if probability < 0.3:
            return "Bajo"
        elif probability < 0.7:
            return "Medio"
        else:
            return "Alto"

    def predict(self, features: Dict[str, float]) -> PredictionResult:
        """Realiza predicción de inundación"""
        try:
            logger.info("Iniciando predicción")
            
            # Verificar features requeridas
            missing_features = set(self.required_features) - set(features.keys())
            if missing_features:
                logger.warning(f"Faltan características: {missing_features}")
                raise ValueError(f"Faltan las siguientes características: {missing_features}")
            
            # Preparar datos para la predicción
            X = np.array([[features[f] for f in self.required_features]])
            X_scaled = self.scaler.transform(X)
            
            # Convertir a formato DMatrix
            dmatrix_data = xgb.DMatrix(X_scaled, feature_names=self.required_features)
            
            # Realizar predicción
            probability = float(self.model.predict(dmatrix_data)[0])
            risk_level = self._get_risk_level(probability)

            prediction = PredictionResult(
                location=features.get('location', 'Tabasco'),
                timestamp=int(datetime.now().timestamp() * 1000),
                flood_probability=probability,
                risk_level=risk_level,
                features_used=features
            )

            logger.info(f"Predicción completada: Probabilidad={probability:.2f}, Riesgo={risk_level}")
            return prediction

        except Exception as e:
            logger.error(f"Error en predicción: {str(e)}")
            raise

    def save_prediction(self, prediction: PredictionResult) -> None:
        """Guarda predicción en Timestream"""
        try:
            logger.info("Guardando predicción en Timestream")
            record = {
                'Dimensions': [
                    {'Name': 'Location', 'Value': prediction.location}
                ],
                'MeasureName': 'FloodPrediction',
                'MeasureValueType': 'MULTI',
                'Time': str(prediction.timestamp),
                'MeasureValues': [
                    {'Name': 'FloodProbability', 'Value': str(prediction.flood_probability), 'Type': 'DOUBLE'},
                    {'Name': 'RiskLevel', 'Value': prediction.risk_level, 'Type': 'VARCHAR'},
                    {'Name': 'Mean_Temperature_C', 'Value': str(prediction.features_used['Mean_Temperature_C']), 'Type': 'DOUBLE'},
                    {'Name': 'Mean_Precipitation', 'Value': str(prediction.features_used['Mean_Precipitation']), 'Type': 'DOUBLE'},
                    {'Name': 'Mean_NDVI', 'Value': str(prediction.features_used['Mean_NDVI']), 'Type': 'DOUBLE'},
                    {'Name': 'Mean_Soil_Moisture', 'Value': str(prediction.features_used['Mean_Soil_Moisture']), 'Type': 'DOUBLE'},
                    {'Name': 'Mean_Evapotranspiration', 'Value': str(prediction.features_used['Mean_Evapotranspiration']), 'Type': 'DOUBLE'}
                ]
            }

            self.timestream_write.write_records(
                DatabaseName='SensorsDB',
                TableName='Predictions',
                Records=[record]
            )
            logger.info("Predicción guardada exitosamente")

        except Exception as e:
            logger.error(f"Error guardando predicción: {str(e)}")
            raise

