from datetime import datetime
from typing import Dict, Optional
from dataclasses import dataclass
import ee
import boto3
import requests
import logging
import time
import os
from dotenv import load_dotenv

# Cargar variables de entorno
load_dotenv()

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@dataclass
class RiverData:
    """Data class for river monitoring information"""
    river_name: str
    location: str
    timestamp: int
    water_level: float
    water_surface_area: float
    precipitation_24h: float
    flow_rate: Optional[float]
    lat: float
    lon: float
    risk_level: str
    river_segment: Dict[str, list]  # Nuevo: coordenadas del segmento del río

class RiverMonitor:
    def __init__(self, region_name: str = None, openweather_api_key: str = None):
        """Initialize services with secure credentials"""
        try:
            # Load environment variables with explicit defaults
            self.openweather_api_key = openweather_api_key or os.environ.get('OPENWEATHER_API_KEY')
            if not self.openweather_api_key:
                raise ValueError("OpenWeather API key not found. Please set the OPENWEATHER_API_KEY environment variable.")
            region_name = region_name or os.getenv('AWS_REGION')
            credentials_path = os.getenv('GEE_CREDENTIALS_PATH')
            service_account = os.getenv('GEE_SERVICE_ACCOUNT')
            
            if not credentials_path:
                raise ValueError("GEE_CREDENTIALS_PATH environment variable not set")
            if not service_account:
                raise ValueError("GEE_SERVICE_ACCOUNT environment variable not set")
            if not os.path.exists(credentials_path):
                raise FileNotFoundError(f"GEE credentials file not found at: {credentials_path}")
                
            credentials = ee.ServiceAccountCredentials(service_account, credentials_path)
            ee.Initialize(credentials)
            logger.info("Google Earth Engine initialized successfully")
            
            # Initialize AWS clients
            self.timestream_write = boto3.client('timestream-write', region_name=region_name)
            self.timestream_query = boto3.client('timestream-query', region_name=region_name)
            self.openweather_api_key = self.openweather_api_key

        except Exception as e:
            logger.error(f"Error initializing Google Earth Engine: {str(e)}")
            raise

        # Definición mejorada de ríos con múltiples puntos de monitoreo y geometría
        self.rivers = {
            'Grijalva': {
                'points': [
                    {'lat': 18.0000, 'lon': -92.9376},
                    {'lat': 17.9950, 'lon': -92.9300},
                    {'lat': 17.9900, 'lon': -92.9250}
                ],
                'geometry': {
                    'type': 'LineString',
                    'coordinates': [
                        [-92.9376, 18.0000],
                        [-92.9300, 17.9950],
                        [-92.9250, 17.9900]
                    ]
                }
            },
            'Usumacinta': {
                'points': [
                    {'lat': 18.1405, 'lon': -92.8500},
                    {'lat': 18.1350, 'lon': -92.8450},
                    {'lat': 18.1300, 'lon': -92.8400}
                ],
                'geometry': {
                    'type': 'LineString',
                    'coordinates': [
                        [-92.8500, 18.1405],
                        [-92.8450, 18.1350],
                        [-92.8400, 18.1300]
                    ]
                }
            },
            'Mezcalapa': {
                'points': [
                    {'lat': 17.800, 'lon': -93.000},
                    {'lat': 17.750, 'lon': -92.950},
                    {'lat': 17.700, 'lon': -92.900}
                ],
                'geometry': {
                    'type': 'LineString',
                    'coordinates': [
                        [-93.000, 17.800],
                        [-92.950, 17.750],
                        [-92.900, 17.700]
                    ]
                }
            },
            'Puxcatán': {
                'points': [
                    {'lat': 17.600, 'lon': -92.800},
                    {'lat': 17.550, 'lon': -92.750},
                    {'lat': 17.500, 'lon': -92.700}
                ],
                'geometry': {
                    'type': 'LineString',
                    'coordinates': [
                        [-92.800, 17.600],
                        [-92.750, 17.550],
                        [-92.700, 17.500]
                    ]
                }
            },
            'San Pedro': {
                'points': [
                    {'lat': 17.500, 'lon': -92.600},
                    {'lat': 17.450, 'lon': -92.550},
                    {'lat': 17.400, 'lon': -92.500}
                ],
                'geometry': {
                    'type': 'LineString',
                    'coordinates': [
                        [-92.600, 17.500],
                        [-92.550, 17.450],
                        [-92.500, 17.400]
                    ]
                }
            }
        }
        self.openweather_url = 'https://api.openweathermap.org/data/2.5/weather'

    def get_weather_data(self, lat: float, lon: float) -> float:
        """Obtiene datos de precipitación desde OpenWeather API"""
        try:
            # Verificar si la clave API está configurada
            if not self.openweather_api_key:
                raise ValueError("OpenWeather API key no está configurada. Verifica las variables de entorno.")

            # Configurar parámetros de la solicitud
            params = {
                'lat': lat,
                'lon': lon,
                'appid': self.openweather_api_key,
                'units': 'metric'
            }
            logger.info(f"Solicitando datos meteorológicos para lat={lat}, lon={lon}")

            # Realizar la solicitud a la API
            response = requests.get(self.openweather_url, params=params, timeout=10)
            response.raise_for_status()  # Lanza un error si el estado HTTP no es 200

            # Procesar respuesta JSON
            weather_data = response.json()

            # Verificar datos de precipitación
            precipitation = weather_data.get('rain', {}).get('1h', 0.0)  # Lluvia en la última hora
            logger.info(f"Datos de precipitación recibidos: {precipitation} mm")

            return precipitation

        except requests.exceptions.HTTPError as e:
            logger.error(f"Error HTTP al obtener datos de OpenWeather: {response.status_code} {response.text}")
            return 0.0  # Regresar 0 como predeterminado en caso de error
        except requests.exceptions.RequestException as e:
            logger.error(f"Error de conexión con OpenWeather: {str(e)}")
            return 0.0
        except ValueError as e:
            logger.error(f"Error de configuración: {str(e)}")
            return 0.0


    def get_river_data(self, river_name: str, river_info: Dict) -> Optional[RiverData]:
        """Obtiene datos del río en múltiples puntos"""
        try:
            # Crear un feature collection con todos los puntos de monitoreo
            points = [ee.Geometry.Point([p['lon'], p['lat']]) for p in river_info['points']]
            monitoring_points = ee.FeatureCollection(points)

            # Buffer para análisis
            river_region = monitoring_points.geometry().buffer(1000)

            # Obtener datos de agua más recientes
            water = ee.ImageCollection('JRC/GSW1_4/MonthlyHistory')\
                .sort('system:time_start', False)\
                .first()

            if not water:
                logger.warning(f"No se encontraron datos para el río {river_name}")
                return None

            # Calcular estadísticas agregadas para todos los puntos
            water_stats = water.reduceRegion(
                reducer=ee.Reducer.mean(),
                geometry=river_region,
                scale=30
            ).getInfo()

            # Obtener nivel promedio del agua
            dem = ee.Image('USGS/SRTMGL1_003')
            water_level = dem.reduceRegion(
                reducer=ee.Reducer.mean(),
                geometry=river_region,
                scale=30
            ).get('elevation').getInfo()

            # Calcular precipitación promedio para todos los puntos
            total_precip = 0
            for point in river_info['points']:
                total_precip += self.get_weather_data(point['lat'], point['lon'])
            avg_precip = total_precip / len(river_info['points'])

            # Crear objeto RiverData con datos agregados
            return RiverData(
                river_name=river_name,
                location='Tabasco',
                timestamp=int(datetime.now().timestamp() * 1000),
                water_level=float(water_level),
                water_surface_area=float(water_stats.get('water', 0)),
                precipitation_24h=avg_precip,
                flow_rate=None,  # Calculado en otra función si es necesario
                lat=river_info['points'][0]['lat'],  # Punto principal
                lon=river_info['points'][0]['lon'],  # Punto principal
                risk_level=self._calculate_risk_level(
                    water_stats.get('water', 0),
                    water_level,
                    avg_precip
                ),
                river_segment=river_info['geometry']
            )

        except Exception as e:
            logger.error(f"Error obteniendo datos para río {river_name}: {str(e)}", exc_info=True)
            return None

    def get_previous_data(self, river_name: str) -> Optional[dict]:
        try:
            query = """
                SELECT time, 
                       WaterLevel,
                       WaterSurfaceArea,
                       Precipitation24h,
                       RiskLevel
                FROM "SensorsDB"."RiverData"
                WHERE RiverName = '{}'
                ORDER BY time DESC
                LIMIT 1
            """.format(river_name)

            response = self.timestream_query.query(QueryString=query)
            if not response['Rows']:
                logger.info(f"No previous data found for {river_name}")
                return None

            data = {}
            for i, value in enumerate(response['Rows'][0]['Data']):
                try:
                    data[response['ColumnInfo'][i]['Name']] = float(value['ScalarValue'])
                except (ValueError, TypeError):
                    if isinstance(value['ScalarValue'], str) and self.is_valid_date(value['ScalarValue']):
                        data[response['ColumnInfo'][i]['Name']] = self.parse_date_to_timestamp(value['ScalarValue'])
                    else:
                        data[response['ColumnInfo'][i]['Name']] = value['ScalarValue']

            return data

        except Exception as e:
            logger.error(f"Error en get_previous_data: {str(e)}", exc_info=True)
            return None

    def is_valid_date(self, date_str: str) -> bool:
        """Check if the string is a valid date"""
        try:
            datetime.strptime(date_str, '%Y-%m-%dT%H:%M:%S.%fZ')
            return True
        except ValueError:
            return False

    def parse_date_to_timestamp(self, date_str: str) -> int:
        """Parse date string to timestamp"""
        try:
            dt = datetime.strptime(date_str, '%Y-%m-%dT%H:%M:%S.%fZ')
            return int(dt.timestamp() * 1000)
        except ValueError:
            return None
        
    def detect_trend(self, current_data: RiverData, previous_data: Optional[dict]) -> str:
        """Detect trends in water levels with configurable thresholds"""
        if not previous_data:
            return "Estable"
            
        try:
            THRESHOLD = 0.5  # Metros
            water_level_diff = current_data.water_level - previous_data['WaterLevel']
            
            if water_level_diff > THRESHOLD:
                return "Incremento"
            elif water_level_diff < -THRESHOLD:
                return "Descenso"
            return "Estable"
            
        except Exception as e:
            logger.error(f"Error detectando tendencia: {str(e)}")
            return "Desconocido"

    def _calculate_risk_level(self, surface_area: float, water_level: float, precipitation: float) -> str:
        """Calcula nivel de riesgo basado en múltiples factores"""
        try:
            # Normalizar valores con umbrales específicos para Tabasco
            norm_surface = min(surface_area / 5000000, 1.0)  # Normalizar a 5km²
            norm_level = min(water_level / 50, 1.0)  # Normalizar a 50m
            norm_precip = min(precipitation / 150, 1.0)  # Normalizar a 150mm

            # Pesos ajustados según importancia
            WEIGHTS = {
                'surface': 0.4,
                'level': 0.4,
                'precipitation': 0.2
            }

            risk_score = (
                norm_surface * WEIGHTS['surface'] +
                norm_level * WEIGHTS['level'] +
                norm_precip * WEIGHTS['precipitation']
            )

            # Niveles de riesgo ajustados
            if risk_score > 0.7:
                return 'Alto'
            elif risk_score > 0.3:
                return 'Medio'
            return 'Bajo'

        except Exception as e:
            logger.error(f"Error calculando nivel de riesgo: {str(e)}")
            return 'Desconocido'

    def save_to_timestream(self, data: RiverData) -> bool:
        """Save river data to Timestream with improved structure"""
        try:
            record = {
                'Dimensions': [
                    {'Name': 'Location', 'Value': data.location},
                    {'Name': 'RiverName', 'Value': data.river_name}
                ],
                'MeasureName': 'RiverData',
                'MeasureValueType': 'MULTI',
                'Time': str(data.timestamp),
                'MeasureValues': [
                    {'Name': 'WaterLevel', 'Value': str(data.water_level), 'Type': 'DOUBLE'},
                    {'Name': 'WaterSurfaceArea', 'Value': str(data.water_surface_area), 'Type': 'DOUBLE'},
                    {'Name': 'Precipitation24h', 'Value': str(data.precipitation_24h), 'Type': 'DOUBLE'},
                    {'Name': 'FlowRate', 'Value': str(data.flow_rate or 0.0), 'Type': 'DOUBLE'},
                    {'Name': 'RiskLevel', 'Value': data.risk_level, 'Type': 'VARCHAR'},
                    {'Name': 'Latitude', 'Value': str(data.lat), 'Type': 'DOUBLE'},
                    {'Name': 'Longitude', 'Value': str(data.lon), 'Type': 'DOUBLE'},
                    {'Name': 'RiverGeometry', 'Value': str(data.river_segment), 'Type': 'VARCHAR'},
                    {'Name': 'Trend', 'Value': 'Estable', 'Type': 'VARCHAR'}  # Se actualizará después
                ]
            }
            
            self.timestream_write.write_records(
                DatabaseName='SensorsDB',
                TableName='RiverData',
                Records=[record]
            )
            logger.info(f"Datos guardados correctamente para el río {data.river_name}")
            return True
        except Exception as e:
            logger.error(f"Error guardando datos en Timestream: {str(e)}")
            return False

def main():
    """Función principal de monitoreo de ríos"""
    try:
        monitor = RiverMonitor()
        
        while True:
            try:
                logger.info("Iniciando ciclo de monitoreo")
                
                for river_name, river_info in monitor.rivers.items():
                    try:
                        logger.info(f"Monitoreando río: {river_name}")
                        river_data = monitor.get_river_data(river_name, river_info)
                        
                        if river_data:
                            # Obtener datos históricos y detectar tendencia
                            previous_data = monitor.get_previous_data(river_name)
                            trend = monitor.detect_trend(river_data, previous_data)
                            
                            # Guardar datos
                            monitor.save_to_timestream(river_data)
                            
                            # Log del resultado
                            logger.info(
                                "Datos procesados para %s:\n"
                                "Nivel de agua: %.2fm\n"
                                "Área de superficie: %.2fm²\n"
                                "Nivel de riesgo: %s\n"
                                "Tendencia: %s",
                                river_name,
                                river_data.water_level,
                                river_data.water_surface_area,
                                river_data.risk_level,
                                trend
                            )
                        else:
                            logger.warning(f"No se pudieron obtener datos para {river_name}")
                            
                    except Exception as e:
                        logger.error(f"Error procesando río {river_name}: {str(e)}")
                        continue
                
                logger.info("Ciclo de monitoreo completado")
                time.sleep(1800)  # 30 minutos
                
            except Exception as e:
                logger.error(f"Error durante el ciclo de monitoreo: {str(e)}")
                time.sleep(300)  # 5 minutos antes de reintentar
                
    except Exception as e:
        logger.critical(f"Error crítico en el servicio: {str(e)}")
        raise

if __name__ == "__main__":
    main()