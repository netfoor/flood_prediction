import requests
import boto3
import logging
from datetime import datetime
from typing import Dict, Optional
from dataclasses import dataclass
from dotenv import load_dotenv
import os

# Cargar variables de entorno desde el archivo .env
load_dotenv()

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('openweather_collector')

@dataclass
class WeatherMeasurement:
    location: str
    timestamp: int
    temperature: float
    feels_like: float
    humidity: float
    pressure_sea: float
    pressure_ground: float
    wind_speed: float
    wind_gust: float
    wind_direction: float
    precipitation: float
    cloudiness: float
    visibility: float

class OpenWeatherCollector:
    def __init__(self, region_name: str = None, openweather_api_key: str = None):
        """Initialize services with secure credentials"""
        try:
            # Load environment variables with explicit defaults
            self.openweather_api_key = openweather_api_key or os.environ.get('OPENWEATHER_API_KEY')
            if not self.openweather_api_key:
                raise ValueError("OpenWeather API key not found")
            self.api_key = self.openweather_api_key
            region = region_name or 'ap-northeast-1'
            self.timestream_client = boto3.client(
                'timestream-write',
                region_name=region,
                aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
                aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY')
            )
            logger.info(f"Inicializado cliente Timestream en región {region}")
        except Exception as e:
            logger.error(f"Error inicializando cliente Timestream: {str(e)}")
            raise

    def fetch_weather_data(self, city_id: str) -> Optional[Dict]:
        url = f'https://api.openweathermap.org/data/2.5/weather?id={city_id}&appid={self.api_key}&units=metric'
        try:
            logger.info(f"Obteniendo datos del clima para ciudad ID: {city_id}")
            response = requests.get(url)
            response.raise_for_status()
            logger.info("Datos del clima obtenidos exitosamente")
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error obteniendo datos de OpenWeather: {str(e)}")
            raise

    def parse_weather_data(self, raw_data: Dict) -> WeatherMeasurement:
        try:
            logger.info("Parseando datos del clima")
            return WeatherMeasurement(
                location='Tabasco',
                timestamp=raw_data['dt'] * 1000,
                temperature=raw_data['main']['temp'],
                feels_like=raw_data['main']['feels_like'],
                humidity=raw_data['main']['humidity'],
                pressure_sea=raw_data['main'].get('sea_level', raw_data['main'].get('pressure', 0)),
                pressure_ground=raw_data['main'].get('grnd_level', raw_data['main'].get('pressure', 0)),
                wind_speed=raw_data['wind']['speed'],
                wind_gust=raw_data['wind'].get('gust', 0),
                wind_direction=raw_data['wind'].get('deg', 0),
                precipitation=raw_data.get('rain', {}).get('1h', 0),
                cloudiness=raw_data['clouds']['all'],
                visibility=raw_data.get('visibility', 10000)
            )
        except KeyError as e:
            logger.error(f"Error parseando datos del clima: Campo faltante {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Error inesperado parseando datos: {str(e)}")
            raise

    def create_timestream_record(self, measurement: WeatherMeasurement) -> Dict:
        logger.info("Creando registro para Timestream")
        return {
            'Dimensions': [
                {'Name': 'Location', 'Value': measurement.location}
            ],
            'MeasureName': 'WeatherData',
            'MeasureValueType': 'MULTI',
            'Time': str(measurement.timestamp),
            'MeasureValues': [
                {'Name': 'Temperature_Current_Celsius', 'Value': str(measurement.temperature), 'Type': 'DOUBLE'},
                {'Name': 'Temperature_FeelsLike_Celsius', 'Value': str(measurement.feels_like), 'Type': 'DOUBLE'},
                {'Name': 'Humidity_Percent', 'Value': str(measurement.humidity), 'Type': 'DOUBLE'},
                {'Name': 'Pressure_SeaLevel_hPa', 'Value': str(measurement.pressure_sea), 'Type': 'DOUBLE'},
                {'Name': 'Pressure_GroundLevel_hPa', 'Value': str(measurement.pressure_ground), 'Type': 'DOUBLE'},
                {'Name': 'WindSpeed_mps', 'Value': str(measurement.wind_speed), 'Type': 'DOUBLE'},
                {'Name': 'WindGust_mps', 'Value': str(measurement.wind_gust), 'Type': 'DOUBLE'},
                {'Name': 'WindDirection_degrees', 'Value': str(measurement.wind_direction), 'Type': 'DOUBLE'},
                {'Name': 'Precipitation_1h_mm', 'Value': str(measurement.precipitation), 'Type': 'DOUBLE'},
                {'Name': 'Cloudiness_Percent', 'Value': str(measurement.cloudiness), 'Type': 'DOUBLE'},
                {'Name': 'Visibility_m', 'Value': str(measurement.visibility), 'Type': 'DOUBLE'}
            ]
        }

    def save_to_timestream(self, record: Dict) -> None:
        try:
            logger.info("Guardando datos en Timestream")
            self.timestream_client.write_records(
                DatabaseName='SensorsDB',
                TableName='WeatherData',
                Records=[record]
            )
            logger.info("Datos guardados exitosamente en Timestream")
        except Exception as e:
            logger.error(f"Error escribiendo en Timestream: {str(e)}")
            raise
