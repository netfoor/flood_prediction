# src/collectors/satellite_collector.py
from datetime import datetime, timedelta
import ee
import boto3
import logging
import os
from typing import Dict, Tuple, Optional  # Agregamos Tuple aquí
from dataclasses import dataclass

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class SatelliteData:
    location: str
    timestamp: int
    ndvi: float
    soil_moisture: float
    evapotranspiration: float
    elevation: float
    slope: float
    ndvi_date: str
    moisture_date: str
    et_date: str

class SatelliteCollector:
    def __init__(self, region_name: str = os.getenv('AWS_REGION', 'ap-northeast-1')):
        """Inicializa EE y servicios AWS"""
        try:
            # Inicializar Earth Engine
            credentials = ee.ServiceAccountCredentials(
                'service-account@your-project.iam.gserviceaccount.com',
                '/app/credentials/ee-credentials.json'
            )
            ee.Initialize(credentials)
            logger.info("Earth Engine inicializado exitosamente")

            # Inicializar cliente Timestream
            self.timestream_client = boto3.client(
                'timestream-write',
                region_name=region_name,
                aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
                aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY')
            )
            logger.info(f"Cliente Timestream inicializado en región {region_name}")

            # En el __init__ de SatelliteCollector
            self.timestream_query = boto3.client(
                'timestream-query',
                region_name=region_name,
                aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
                aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY')
            )

            # Obtener región de Tabasco
            self.region = self._get_tabasco_region()
            logger.info("Región de Tabasco cargada")
            
        except Exception as e:
            logger.error(f"Error en inicialización: {str(e)}")
            raise

    def get_last_valid_data(self, measure_name: str) -> Optional[Tuple[float, str]]:
        """
        Obtiene el último dato válido de Timestream
        """
        try:
            query = f"""
            SELECT {measure_name}
            FROM "SensorsDB"."SatelliteData"
            WHERE Location = 'Tabasco'
            ORDER BY time DESC
            LIMIT 1
            """
            
            logger.info(f"Buscando último dato válido para {measure_name} en Timestream")
            
            try:
                result = self.timestream_query.query(QueryString=query)
                if result['Rows'] and result['Rows'][0]['Data'][0]['ScalarValue']:
                    value = float(result['Rows'][0]['Data'][0]['ScalarValue'])
                    # Usar la fecha actual como fecha del dato
                    current_date = datetime.now().strftime('%Y-%m-%d')
                    logger.info(f"Recuperado último dato válido de {measure_name}: {value}")
                    return value, current_date
            except Exception as e:
                logger.warning(f"No se encontraron datos previos en Timestream para {measure_name}: {str(e)}")
                return None
                
        except Exception as e:
            logger.error(f"Error recuperando datos de Timestream: {str(e)}")
            return None

    def _get_tabasco_region(self) -> ee.Geometry:
        """Obtiene geometría de Tabasco"""
        return ee.FeatureCollection('FAO/GAUL/2015/level2') \
            .filter(ee.Filter.eq('ADM1_NAME', 'Tabasco')) \
            .geometry()

    def _get_latest_available_image(self, collection_id: str, band: str, scale: int) -> Tuple[float, str]:
        """
        Obtiene la imagen más reciente disponible y su fecha
        Returns:
            tuple: (valor, fecha_imagen)
        """
        try:
            # Obtener la colección y ordenar por fecha
            collection = ee.ImageCollection(collection_id)\
                .filterBounds(self.region)\
                .select(band)
            
            # Obtener la imagen más reciente
            latest_image = collection\
                .sort('system:time_start', False)\
                .first()
                
            # Obtener la fecha de la imagen
            image_date = ee.Date(latest_image.get('system:time_start')).format('YYYY-MM-dd').getInfo()
            
            # Obtener el valor
            value = latest_image.reduceRegion(
                reducer=ee.Reducer.mean(),
                geometry=self.region,
                scale=scale
            ).get(band).getInfo()
            
            if value is None:
                raise ValueError(f"No se encontró valor para la banda {band}")
                
            logger.info(f"Datos obtenidos para la fecha: {image_date}")
            return value, image_date
            
        except Exception as e:
            logger.error(f"Error obteniendo imagen más reciente: {str(e)}")
            raise

    def get_modis_ndvi(self) -> Tuple[float, str]:
        """
        Obtiene el NDVI más reciente disponible
        Returns:
            tuple: (ndvi_value, date)
        """
        logger.info("Obteniendo últimos datos NDVI disponibles")
        value, date = self._get_latest_available_image(
            collection_id='MODIS/061/MOD13A1',
            band='NDVI',
            scale=500
        )
        # Aplicar factor de escala MODIS
        return value * 0.0001, date

    def get_soil_moisture(self) -> Tuple[float, str]:
        """
        Obtiene la humedad del suelo más reciente
        Returns:
            tuple: (soil_moisture_value, date)
        """
        logger.info("Obteniendo últimos datos de humedad del suelo")
        return self._get_latest_available_image(
            collection_id='NASA/SMAP/SPL4SMGP/007',
            band='sm_surface',
            scale=500
        )

    def get_evapotranspiration(self) -> Tuple[float, str]:
        """
        Obtiene la evapotranspiración más reciente
        Returns:
            tuple: (et_value, date)
        """
        logger.info("Obteniendo últimos datos de evapotranspiración")
        value, date = self._get_latest_available_image(
            collection_id='MODIS/061/MOD16A2GF',
            band='ET',
            scale=500
        )
        # Aplicar factor de escala
        return value * 0.1, date
    
    def get_static_features(self) -> Dict[str, float]:
        """Obtiene características estáticas (elevación, pendiente)"""
        try:
            logger.info("Obteniendo características estáticas")
            dem = ee.Image('USGS/SRTMGL1_003').clip(self.region)
            slope = ee.Terrain.slope(dem)
            
            elevation = dem.reduceRegion(
                reducer=ee.Reducer.mean(),
                geometry=self.region,
                scale=500
            ).get('elevation').getInfo()
            
            slope_val = slope.reduceRegion(
                reducer=ee.Reducer.mean(),
                geometry=self.region,
                scale=500
            ).get('slope').getInfo()
            
            return {
                'elevation': elevation,
                'slope': slope_val
            }
        except Exception as e:
            logger.error(f"Error obteniendo características estáticas: {str(e)}")
            raise

    def create_timestream_record(self, data: SatelliteData) -> Dict:
        """Crea registro para Timestream"""
        logger.info("Creando registro Timestream")
        return {
            'Dimensions': [
                {'Name': 'Location', 'Value': data.location}
            ],
            'MeasureName': 'SatelliteData',
            'MeasureValueType': 'MULTI',
            'Time': str(data.timestamp),
            'MeasureValues': [
                {'Name': 'NDVI', 'Value': str(data.ndvi), 'Type': 'DOUBLE'},
                {'Name': 'NDVI_Date', 'Value': data.ndvi_date, 'Type': 'VARCHAR'},
                {'Name': 'SoilMoisture', 'Value': str(data.soil_moisture), 'Type': 'DOUBLE'},
                {'Name': 'SoilMoisture_Date', 'Value': data.moisture_date, 'Type': 'VARCHAR'},
                {'Name': 'Evapotranspiration', 'Value': str(data.evapotranspiration), 'Type': 'DOUBLE'},
                {'Name': 'Evapotranspiration_Date', 'Value': data.et_date, 'Type': 'VARCHAR'},
                {'Name': 'Elevation', 'Value': str(data.elevation), 'Type': 'DOUBLE'},
                {'Name': 'Slope', 'Value': str(data.slope), 'Type': 'DOUBLE'}
            ]
        }

    def save_to_timestream(self, record: Dict) -> None:
        """Guarda registro en Timestream"""
        try:
            logger.info("Guardando datos en Timestream")
            self.timestream_client.write_records(
                DatabaseName='SensorsDB',
                TableName='SatelliteData',
                Records=[record]
            )
            logger.info("Datos guardados exitosamente")
        except Exception as e:
            logger.error(f"Error escribiendo en Timestream: {str(e)}")
            raise