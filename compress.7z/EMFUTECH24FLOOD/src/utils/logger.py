# utils/logger.py
import logging
import os
from logging.handlers import RotatingFileHandler

def setup_logger(name: str, log_dir: str = '/app/logs') -> logging.Logger:
    """
    Configura un logger con formato consistente y rotación de archivos
    
    Args:
        name: Nombre del logger
        log_dir: Directorio donde se guardarán los logs
        
    Returns:
        Logger configurado
    """
    # Crear directorio de logs si no existe
    os.makedirs(log_dir, exist_ok=True)
    
    # Crear logger
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    
    # Formato para los logs
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # Handler para consola
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # Handler para archivo con rotación
    file_handler = RotatingFileHandler(
        filename=os.path.join(log_dir, f'{name}.log'),
        maxBytes=10485760,  # 10MB
        backupCount=5,      # Mantener 5 archivos de backup
        encoding='utf-8'
    )
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    
    return logger