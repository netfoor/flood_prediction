# scripts/predictor_main.py
import os
import time
from datetime import datetime
import logging
from predictor.flood_predictor import FloodPredictor

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('/app/logs/predictor.log')
    ]
)
logger = logging.getLogger('predictor_main')

def main():
    try:
        logger.info("Iniciando Flood Predictor")
        
        # Inicializar predictor
        predictor = FloodPredictor(
            model_path='/app/models/flood_model_optimized.pkl',
            scaler_path='/app/models/scaler.pkl',
            region_name=os.getenv('AWS_REGION', 'ap-northeast-1')
        )
        
        location = 'Tabasco'
        
        while True:
            try:
                logger.info("Iniciando ciclo de predicción")
                
                # Obtener datos integrados
                integrated_data = predictor.get_integrated_data(location)
                
                if integrated_data:
                    # Realizar predicción
                    prediction = predictor.predict(integrated_data)
                    predictor.save_prediction(prediction)
                    
                    logger.info(f"""
                    Predicción completada:
                    Probabilidad de inundación: {prediction.flood_probability:.2%}
                    Nivel de riesgo: {prediction.risk_level}
                    Temperatura: {prediction.features_used['Mean_Temperature_C']:.2f}°C
                    Precipitación: {prediction.features_used['Mean_Precipitation']:.2f}mm
                    NDVI: {prediction.features_used['Mean_NDVI']:.4f}
                    """)
                else:
                    logger.warning("No hay datos suficientes para realizar predicción")
                
                # Esperar para siguiente predicción
                logger.info("Esperando 1 hora para siguiente predicción")
                time.sleep(3600)  # 1 hora
                
            except Exception as e:
                logger.error(f"Error durante el ciclo de predicción: {str(e)}")
                logger.info("Esperando 5 minutos antes de reintentar")
                time.sleep(300)  # 5 minutos
                
    except Exception as e:
        logger.error(f"Error crítico en el servicio: {str(e)}")
        raise

if __name__ == "__main__":
    main()