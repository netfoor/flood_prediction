# scripts/satellite_main.py
import os
import time
from datetime import datetime
import logging
from collectors.satellite_collector import SatelliteCollector, SatelliteData
from typing import Optional, Tuple  # Agregamos Tuple aquí
from typing import Optional

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('/app/logs/satellite_collector.log')
    ]
)
logger = logging.getLogger('satellite_main')

def get_satellite_data(collector: SatelliteCollector) -> Optional[SatelliteData]:
    """
    Obtiene datos satelitales con validación flexible y sistema de fallback
    """
    try:
        # Obtener datos actuales
        ndvi_current = collector.get_modis_ndvi()
        moisture_current = collector.get_soil_moisture()
        et_current = collector.get_evapotranspiration()

        # Diccionario para almacenar los datos finales
        final_data = {
            'ndvi': {'value': None, 'date': None},
            'moisture': {'value': None, 'date': None},
            'et': {'value': None, 'date': None}
        }

        # Límites de antigüedad más flexibles
        max_age_days = {
            'ndvi': 30,      # Aumentado de 16 a 30 días
            'moisture': 7,    # Aumentado de 3 a 7 días
            'et': 60         # Aumentado de 8 a 60 días
        }

        current_date = datetime.now()

        # Función para validar y obtener el mejor dato disponible
        def get_best_data(data_type: str, current_data: Tuple[float, str]) -> Tuple[float, str]:
            value, date = current_data
            data_date = datetime.strptime(date, '%Y-%m-%d')
            age_days = (current_date - data_date).days

            if age_days <= max_age_days[data_type]:
                logger.info(f"Usando datos actuales de {data_type}: {value:.4f} ({date})")
                return value, date

            # Si los datos son muy antiguos, intentar fallback
            logger.warning(f"Datos de {data_type} muy antiguos ({age_days} días), intentando fallback")
            
            # Usar los nombres correctos para el fallback
            measure_name = {
                'ndvi': 'NDVI',
                'moisture': 'SoilMoisture',
                'et': 'Evapotranspiration'
            }[data_type]
            
            fallback_data = collector.get_last_valid_data(measure_name)
            
            if fallback_data:
                fallback_value, fallback_date = fallback_data
                logger.info(f"Usando datos de fallback para {data_type}: {fallback_value:.4f} ({fallback_date})")
                return fallback_value, fallback_date

            # Si no hay datos en Timestream, usar ajuste estacional para ET
            if data_type == 'et':
                logger.warning(f"Usando ajuste estacional para {data_type}")
                seasonal_factors = {
                    1: 0.7,  # enero
                    2: 0.8,
                    3: 0.9,
                    4: 1.0,
                    5: 1.1,
                    6: 1.2,
                    7: 1.2,
                    8: 1.1,
                    9: 1.0,
                    10: 0.9,
                    11: 0.8,
                    12: 0.7
                }
                current_month = datetime.now().month
                adjusted_value = value * seasonal_factors[current_month]
                current_date_str = datetime.now().strftime('%Y-%m-%d')
                logger.info(f"Valor ajustado por temporada: {adjusted_value:.4f}")
                return adjusted_value, current_date_str

            # Si todo lo demás falla, usar los datos actuales con advertencia
            logger.warning(f"Usando datos originales para {data_type} a pesar de su antigüedad")
            return value, date

        # Obtener los mejores datos disponibles
        final_data['ndvi']['value'], final_data['ndvi']['date'] = get_best_data('ndvi', ndvi_current)
        final_data['moisture']['value'], final_data['moisture']['date'] = get_best_data('moisture', moisture_current)
        final_data['et']['value'], final_data['et']['date'] = get_best_data('et', et_current)

        # Obtener características estáticas
        static_features = collector.get_static_features()

        # Crear objeto de datos
        satellite_data = SatelliteData(
            location='Tabasco',
            timestamp=int(datetime.now().timestamp() * 1000),
            ndvi=final_data['ndvi']['value'],
            soil_moisture=final_data['moisture']['value'],
            evapotranspiration=final_data['et']['value'],
            elevation=static_features['elevation'],
            slope=static_features['slope'],
            ndvi_date=final_data['ndvi']['date'],
            moisture_date=final_data['moisture']['date'],
            et_date=final_data['et']['date']
        )

        logger.info(f"""
        Datos recolectados exitosamente:
        NDVI: {satellite_data.ndvi:.4f} (fecha: {satellite_data.ndvi_date})
        Humedad: {satellite_data.soil_moisture:.4f} (fecha: {satellite_data.moisture_date})
        Evapotranspiración: {satellite_data.evapotranspiration:.4f} (fecha: {satellite_data.et_date})
        """)

        return satellite_data

    except Exception as e:
        logger.error(f"Error obteniendo datos satelitales: {str(e)}")
        return None

def main():
    try:
        logger.info("Iniciando Satellite Collector")
        collector = SatelliteCollector()
        
        while True:
            try:
                logger.info("Iniciando ciclo de recolección")
                
                # Obtener datos
                data = get_satellite_data(collector)
                
                if data:
                    # Guardar en Timestream
                    record = collector.create_timestream_record(data)
                    collector.save_to_timestream(record)
                    logger.info(
                        f"Datos guardados exitosamente:\n"
                        f"NDVI: {data.ndvi:.4f} ({data.ndvi_date})\n"
                        f"Humedad: {data.soil_moisture:.4f} ({data.moisture_date})\n"
                        f"ET: {data.evapotranspiration:.4f} ({data.et_date})"
                    )
                else:
                    logger.warning("No se obtuvieron datos válidos en este ciclo")
                
                # Esperar para el siguiente ciclo
                logger.info("Esperando 12 horas para la siguiente recolección")
                time.sleep(43200)  # 12 horas
                
            except Exception as e:
                logger.error(f"Error durante la recolección: {str(e)}")
                logger.info("Esperando 15 minutos antes de reintentar")
                time.sleep(900)  # 15 minutos
                
    except Exception as e:
        logger.error(f"Error crítico en el servicio: {str(e)}")
        raise

if __name__ == "__main__":
    main()