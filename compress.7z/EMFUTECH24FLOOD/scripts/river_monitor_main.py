import os
import time
from datetime import datetime
import logging
from collectors.river_monitor import RiverMonitor
from dotenv import load_dotenv

# Cargar variables de entorno
load_dotenv()

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('river_monitor_main')

def main():
    try:
        logger.info("Iniciando monitoreo de ríos")
        monitor = RiverMonitor()
        
        while True:
            try:
                logger.info("Iniciando ciclo de monitoreo")
                
                for river_name, coords in monitor.rivers.items():
                    try:
                        logger.info(f"Monitoreando río: {river_name}")
                        river_data = monitor.get_river_data(river_name, coords)
                        
                        if river_data:
                            # Obtener datos históricos y detectar tendencia
                            previous_data = monitor.get_previous_data(river_name)
                            trend = monitor.detect_trend(river_data, previous_data)
                            
                            # Guardar datos
                            monitor.save_to_timestream(river_data)
                            
                            # Verificar alertas
                            if river_data.risk_level == "Alto" or trend == "Incremento":
                                monitor.send_alert(river_name, river_data.risk_level)
                            
                            flow_rate = f"{river_data.flow_rate:.2f}m³/s" if river_data.flow_rate else "0.00m³/s"
                            logger.info(
                                f"Datos procesados para {river_name}:\n"
                                f"Nivel de agua: {river_data.water_level:.2f}m\n"
                                f"Área de superficie: {river_data.water_surface_area:.2f}m²\n"
                                f"Tasa de flujo: {flow_rate}\n"
                                f"Nivel de riesgo: {river_data.risk_level}\n"
                                f"Tendencia: {trend}"
                            )

                        else:
                            logger.warning(f"No se pudieron obtener datos para {river_name}")
                            
                    except Exception as e:
                        logger.error(f"Error procesando río {river_name}: {str(e)}", exc_info=True)
                        continue
                
                logger.info("Ciclo de monitoreo completado")
                time.sleep(10800)  # 3 horas
                
            except Exception as e:
                logger.error(f"Error durante el ciclo de monitoreo: {str(e)}", exc_info=True)
                time.sleep(300)  # 5 minutos antes de reintentar
                
    except Exception as e:
        logger.critical(f"Error crítico en el servicio: {str(e)}", exc_info=True)
        raise

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logger.critical(f"Fallo en la aplicación: {str(e)}", exc_info=True)
        exit(1)