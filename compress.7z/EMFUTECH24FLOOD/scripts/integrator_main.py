import os
import time
from datetime import datetime
import logging
from integrator.data_integrator import DataIntegrator, IntegratedData

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('/app/logs/integrator.log')
    ]
)
logger = logging.getLogger('integrator_main')

def main():
    try:
        logger.info("Iniciando Data Integrator")
        integrator = DataIntegrator(region_name=os.getenv('AWS_REGION', 'ap-northeast-1'))
        
        while True:
            try:
                logger.info("Iniciando ciclo de integración")
                
                # Integrar datos para Tabasco
                data = integrator.integrate_data('Tabasco')
                
                if data:
                    # Guardar datos integrados
                    integrator.save_integrated_data(data)
                    logger.info(f"""
                    Datos integrados exitosamente:
                    Temperatura: {data.temperature:.2f}°C
                    Precipitación: {data.precipitation:.2f}mm
                    Humedad: {data.humidity:.2f}%
                    NDVI: {data.ndvi:.4f}
                    Humedad del Suelo: {data.soil_moisture:.4f}
                    Evapotranspiración: {data.evapotranspiration:.2f}
                    """)
                else:
                    logger.warning("No se obtuvieron suficientes datos para la integración")
                
                # Esperar 1 hora antes de la siguiente integración
                logger.info("Esperando 1 hora para la siguiente integración")
                time.sleep(3600)  # 1 hora
                
            except Exception as e:
                logger.error(f"Error durante la integración: {str(e)}")
                logger.info("Esperando 5 minutos antes de reintentar")
                time.sleep(300)  # 5 minutos
                
    except Exception as e:
        logger.error(f"Error crítico en el servicio: {str(e)}")
        raise

if __name__ == "__main__":
    main()
