import os
import time
import logging
from datetime import datetime
from collectors.openweather_collector import OpenWeatherCollector

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('/app/logs/weather_collector.log')
    ]
)
logger = logging.getLogger('weather_main')

def main():
    try:
        api_key = os.getenv('OPENWEATHER_API_KEY')
        city_id = os.getenv('CITY_ID')
        region = os.getenv('AWS_REGION', 'ap-northeast-1')

        if not api_key or not city_id:
            raise ValueError("OPENWEATHER_API_KEY y CITY_ID son requeridos")

        logger.info(f"API Key: {api_key}, City ID: {city_id}, Region: {region}")
        logger.info("Iniciando Weather Collector")

        collector = OpenWeatherCollector(api_key=api_key, region=region)
        
        while True:
            try:
                logger.info("Iniciando ciclo de recolección")
                raw_data = collector.fetch_weather_data(city_id)
                measurement = collector.parse_weather_data(raw_data)
                record = collector.create_timestream_record(measurement)
                collector.save_to_timestream(record)
                logger.info("Ciclo de recolección completado exitosamente")

                # Esperar 30 minutos antes de la siguiente recolección
                logger.info("Esperando 30 minutos para la siguiente recolección")
                time.sleep(1800)
            except Exception as e:
                logger.error(f"Error durante la recolección: {str(e)}")
                logger.info("Esperando 5 minutos antes de reintentar")
                time.sleep(300)
    except Exception as e:
        logger.error(f"Error crítico en el servicio: {str(e)}")
        raise

if __name__ == "__main__":
    main()
